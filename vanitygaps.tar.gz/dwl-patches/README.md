### Description
Adds (inner) gaps between client windows and (outer) gaps between windows and
the screen edge in a flexible manner.

### Download
- [git branch](https://codeberg.org/sevz/dwl/src/branch/vanitygaps)
- [main 2025-01-20](/dwl/dwl-patches/raw/branch/main/patches/vanitygaps/vanitygaps.patch)
- [vanitygaps-0.7.patch](/dwl/dwl-patches/raw/branch/main/patches/vanitygaps/vanitygaps-0.7.patch)

### Authors
- [sevz](https://codeberg.org/sevz)
- [Bonicgamer](https://github.com/Bonicgamer)
